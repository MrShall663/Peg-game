package cs3500.pyramidsolitaire.controller;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;
import cs3500.pyramidsolitaire.view.PyramidSolitaireTextualView;

/**
 * Represents textual controller for pyramid solitaire.
 */
public class PyramidSolitaireTextualController implements PyramidSolitaireController {
  private final Readable read;
  private final Appendable out;

  /**
   * Constructor for textual controller.
   *
   * @param rd Readable input.
   * @param ap Appendable input.
   * @throws IllegalArgumentException when readable or appendable are null.
   */
  public PyramidSolitaireTextualController(Readable rd, Appendable ap) {
    if (rd == null || ap == null) {
      throw new IllegalArgumentException("readable or appendable null");
    }
    this.read = rd;
    this.out = ap;
  }

  /**
   * The primary method for beginning and playing a game.
   *
   * @param <K> the type of cards used by the model.
   * @param model The game of solitaire to be played
   * @param deck The deck of cards to be used
   * @param shuffle Whether to shuffle the deck or not
   * @param numRows How many rows should be in the pyramid
   * @param numDraw How many draw cards should be visible
   * @throws IllegalArgumentException if the model or deck is null
   * @throws IllegalStateException if the game cannot be started,
   *          or if the controller cannot interact with the player.
   */
  public <K> void playGame(PyramidSolitaireModel<K> model, List<K> deck, boolean shuffle,
      int numRows, int numDraw) {
    if (model == null) {
      throw new IllegalArgumentException("model or deck are null \n");
    }
    int[] inputs = new int[4];
    try {
      model.startGame(deck, shuffle, numRows, numDraw);
    } catch (IllegalArgumentException e) {
      throw new IllegalArgumentException("Invalid game start");
    }
    Scanner scan = new Scanner(this.read);
    PyramidSolitaireTextualView view = new PyramidSolitaireTextualView(model, this.out);
    label:
    while (!model.isGameOver()) {

      try {
        view.render();
        this.out.append("\nScore: " + model.getScore() + "\n");
      } catch (IOException e) {
        throw new IllegalStateException("IO exception");
      }
      String command = "";
      if (scan.hasNext()) {
        command = scan.next();
      } else {
        break;
      }
      try {
        switch (command) {
          case "rm1":
            inputs[0] = this.getNextInput(scan);
            inputs[1] = this.getNextInput(scan);
            try {
              model.remove(inputs[0], inputs[1]);
            } catch (IllegalArgumentException e) {
              this.appendWithExceptionMessage(
                  "Invalid move. Please play again. " + "rm1 had an illegal argument");
            }
            break;
          case "rm2":
            inputs[0] = this.getNextInput(scan);
            inputs[1] = this.getNextInput(scan);
            inputs[2] = this.getNextInput(scan);
            inputs[3] = this.getNextInput(scan);
            try {
              model.remove(inputs[0], inputs[1], inputs[2], inputs[3]);
            } catch (IllegalArgumentException e) {
              this.appendWithExceptionMessage(
                  "Invalid move. Please play again. " + "rm2 had an illegal argument");
            }
            break;
          case "rmwd":
            inputs[0] = this.getNextInput(scan);
            inputs[1] = this.getNextInput(scan);
            inputs[2] = this.getNextInput(scan);
            try {
              model.removeUsingDraw(inputs[0], inputs[1], inputs[2]);
            } catch (IllegalArgumentException e) {
              this.appendWithExceptionMessage(
                  "Invalid move. Please play again. " + "rmwd had an illegal argument");
            }
            break;
          case "dd":
            inputs[0] = this.getNextInput(scan);
            try {
              model.discardDraw(inputs[0]);
            } catch (IllegalArgumentException e) {
              this.appendWithExceptionMessage(
                  "Invalid move. Please play again. " + "dd had an illegal argument");
            }
            break;
          case "q":
            break label;
          default:
            this.appendWithExceptionMessage("Invalid move. Please play again.");
            break;
        }
      } catch (InputIsQuitException e) {
        break;
      }
    }
    if (model.isGameOver()) {
      try {
        view.render();
      } catch (IOException e) {
        throw new IllegalStateException("Appendable failed to take");
      }
    } else {
      try {
        this.out.append("Game quit!\nState of game when quit:\n");
        view.render();
        this.out.append("\nScore: " + model.getScore() + "\n");
      } catch (IOException e) {
        throw new IllegalStateException("Appendable failed to take");
      }
    }

    scan.close();
  }

  /**
   * To get the next input.
   *
   * @param scan represent a scanner
   * @return return a int
   * @throws InputIsQuitException if the input is quit
   */
  private int getNextInput(Scanner scan) throws InputIsQuitException {
    String input = scan.next();
    int num;
    while (true) {
      if (input.equalsIgnoreCase("q")) {
        throw new InputIsQuitException("Input is quit");
      }
      try {
        num = Integer.parseInt(input);
        return num - 1;
      } catch (NumberFormatException e) {
        this.appendWithExceptionMessage("Bad Argument: " + input);
      }
      input = scan.next();
    }
  }

  /**
   * To append exception with given message.
   *
   * @param message the given message
   */
  void appendWithExceptionMessage(String message) {
    try {
      this.out.append(message + "\n");
    } catch (IOException e1) {
      throw new IllegalStateException("Appendable failed to take\n");
    }
  }
}
