
package cs3500.pyramidsolitaire.controller;

/**
 * represents an input is quit exception.
 */
public class InputIsQuitException extends Exception {

  private static final long serialVersionUID = 1L;

  /**
   * Constructor for InputIsQuitException class.
   *
   * @param message the message of the exception.
   */
  public InputIsQuitException(String message) {
    super(message);
  }
}