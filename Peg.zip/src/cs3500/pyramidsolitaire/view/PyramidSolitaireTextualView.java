package cs3500.pyramidsolitaire.view;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;

/**
 * A basic view for playing a game of pyramid solitaire that maintains the state and enforces the
 * rules of gameplay. Uses the Card class to represent cards.
 */
public class PyramidSolitaireTextualView implements PyramidSolitaireView {

  private final PyramidSolitaireModel<?> model;
  private final Appendable out;

  public PyramidSolitaireTextualView(PyramidSolitaireModel<?> model, Appendable ap) {
    this.model = model;
    this.out = ap;
  }

  /**
   * Constructor for view.
   *
   * @param model the model of solitaire.
   */
  public PyramidSolitaireTextualView(PyramidSolitaireModel<?> model) {
    this.model = model;
    this.out = null;
  }

  @Override
  public String toString() {
    if (this.model.getNumRows() == -1) {
      return "";
    }
    if (this.model.getScore() == 0) {
      return "You win!";
    }
    if (this.model.isGameOver()) {
      return "Game over. Score: " + this.model.getScore();
    }
    ArrayList<String> pyramid = new ArrayList<String>();
    for (int i = 0; i < model.getNumRows(); i++) {
      String currentRow = "";
      for (int j = 0; j < model.getRowWidth(i); j++) {
        Object currentCard = model.getCardAt(i, j);
        if (currentCard == null) {
          currentRow = currentRow + " " + ".  ";
        } else {
          String currentCardString = currentCard.toString();
          if (currentCardString.length() == 2) {
            currentCardString = currentCardString + " ";
          }
          currentRow = currentRow + " " + currentCardString;
        }
      }
      String paddingSpaces = "";
      for (int k = i; k < model.getNumRows() - 1; k++) {
        paddingSpaces = paddingSpaces + "  ";
      }
      if (currentRow.substring(currentRow.length() - 1).equals(" ")) {
        pyramid
            .add(paddingSpaces + currentRow.substring(1, currentRow.length() - 1));
      } else {
        pyramid
            .add(paddingSpaces + currentRow.substring(1, currentRow.length()));
      }
    }
    List<?> drawCards = model.getDrawCards();
    String drawView = "";
    int count = 0;
    for (Object dc : drawCards) {
      count = 1;
      drawView = drawView + " " + dc.toString() + ",";
    }
    pyramid.add("Draw:" + drawView.substring(0, drawView.length() - count));
    String base = "";
    for (String row : pyramid) {
      row = "." + row;
      row = row.trim();
      base = base + row.substring(1, row.length()) + "\n";
    }
    return base.substring(0, base.length() - 1);
  }


  @Override
  public void render() throws IOException {
    this.out.append(this.toString());
  }
}
