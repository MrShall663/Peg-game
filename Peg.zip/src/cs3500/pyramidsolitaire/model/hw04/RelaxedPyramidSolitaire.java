package cs3500.pyramidsolitaire.model.hw04;

import cs3500.pyramidsolitaire.model.hw02.Card;

/**
 * A abstract class for a basic model for playing a game of pyramid solitaire that maintains the
 * state and enforces the rules of gameplay. Uses the Card class to represent cards. We can relax
 * the rules for which cards can be removed, though. If a card is covered by only one other card,
 * and the player is trying to remove those two cards as a pair, then we treat the pair as uncovered
 * and permit it to be removed it if adds up to 13 as desired.
 */
public class RelaxedPyramidSolitaire extends AbstractPyramidSolitaire {

  /**
   * Signal if the game is over or not. A game is said to be over if there are no possible removes
   * or discards.
   *
   * @return true if game is over, false otherwise
   * @throws IllegalStateException if the game hasn't been started yet
   */
  public boolean isGameOver() throws IllegalStateException {
    super.gameStateException();
    for (int i = 0; i < this.pyramid.size() - 1; i++) {
      for (int j = 0; j < this.pyramid.get(i).size(); j++) {
        try {
          if (this.isExposedHelp(i, j)) {
            if (((super.getCardRemoved(i, j).getValue()
                + super.getCardRemoved(i + 1, j + 1).getValue() == 13) && super
                .isExposed(i + 1, j + 1)) || (super.getCardRemoved(i, j).getValue()
                + super.getCardRemoved(i + 1, j).getValue() == 13) &&
                (super.isExposed(i + 1, j))
            ) {
              return false;
            }
          }
        } catch (IllegalArgumentException ignored) {
        }
      }
    }
    return super.isGameOver();
  }

  /**
   * check if the given card is exposed in a new solitaire.
   *
   * @param row  row of the given card
   * @param card column of the given card
   * @throws IllegalArgumentException if invalid position given
   */
  private boolean isExposedHelp(int row, int card) {
    if (this.getCardRemoved(row, card) == null) {
      return false;
    }
    if (this.pyramid.size() - 1 == row) {
      return true;
    }
    if (this.checkCard(row, card)) {
      throw new IllegalArgumentException("invalid row or card");
    } else {
      return xor(this.getCardRemoved(row + 1, card) == null,
          this.getCardRemoved(row + 1, card + 1) == null);
    }
  }

  /**
   * Remove two exposed cards on the pyramid, using the two specified card positions.
   *
   * @param row1  row of first card position, numbered from 0 from the top of the pyramid
   * @param card1 card of first card position, numbered from 0 from left
   * @param row2  row of second card position
   * @param card2 card of second card position
   * @throws IllegalArgumentException if the attempted remove is invalid
   * @throws IllegalStateException    if the game has not yet been started
   */
  public void remove(int row1, int card1, int row2, int card2) throws IllegalStateException {
    try {
      super.remove(row1, card1, row2, card2);
    } catch (IllegalArgumentException e) {
      Card c2 = this.getCardRemoved(row2, card2);
      Card c1 = this.getCardRemoved(row1, card1);
      if (this.checkCard(row2, card2) || this.checkCard(row1, card1)) {
        throw new IllegalArgumentException("Invalid row or card");
      }
      if (card2 == card1 && row2 == row1) {
        throw new IllegalArgumentException("given the same card");
      }
      if (
          !super.isExposed(row1, card1) && this.isExposedHelp(row2, card2)
              || !super.isExposed(row2, card2) && !(this.isExposedHelp(row1, card1))) {
        throw new IllegalArgumentException(
            "given cards are not exposed");
      }
      if (13 != c2.getValue() + c1.getValue()) {
        throw new IllegalArgumentException("two given cards do not sum to 13");
      }
      if (!(
          (row1 + 1 == row2) && (card2 == card1 || card1 + 1 == card2)
              || (card2 + 1 == card1 || card2 == card1) && (row2 + 1 == row1))) {
        throw new IllegalArgumentException("two given cards are not pairs");
      }
      this.pyramid.get(row1).set(card1, Card.EMPTY_CARD);
      this.pyramid.get(row2).set(card2, Card.EMPTY_CARD);
    }
  }

  /**
   * xor the two given booleans.
   *
   * @param x first boolean.
   * @param y second boolean.
   * @return xor result
   */
  private boolean xor(boolean x, boolean y) {
    return (x && !y) || (y && !x);
  }
}

