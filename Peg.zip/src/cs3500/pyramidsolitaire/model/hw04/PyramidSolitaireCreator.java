package cs3500.pyramidsolitaire.model.hw04;

import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;

/**
 * The class should define a public enum GameType with three possible values: BASIC , RELAXED and
 * MULTIPYRAMID . It should offer a static factory method create(GameType type) that returns an
 * instance of (an appropriate subclass of) PyramidSolitaireModel , depending on the value of the
 * parameter.
 */
public class PyramidSolitaireCreator {

  /**
   * Three game types: basic, multi-pyramid, relaxed.
   */
  public enum GameType {
    BASIC, MULTIPYRAMID, RELAXED;
  }

  /**
   * To create model of given gametype.
   *
   * @param gametype enum BASIC, MULTIPYRAMID, or RELAXED.
   * @return PyramidSolitaireModel (model).
   */
  public static PyramidSolitaireModel create(GameType gametype) {
    switch (gametype) {
      case BASIC:
        return new BasicPyramidSolitaire();
      case MULTIPYRAMID:
        return new MultiPyramidSolitaire();
      case RELAXED:
        return new RelaxedPyramidSolitaire();
      default:
        return null;
    }
  }
}
