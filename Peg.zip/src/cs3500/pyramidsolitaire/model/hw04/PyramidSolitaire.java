package cs3500.pyramidsolitaire.model.hw04;

import cs3500.pyramidsolitaire.controller.PyramidSolitaireTextualController;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;
import cs3500.pyramidsolitaire.model.hw04.PyramidSolitaireCreator.GameType;
import java.io.InputStreamReader;

/**
 * This main() method will be the entry point for my program. My program needs to take inputs as
 * command-line arguments.
 */
public final class PyramidSolitaire {

  /**
   * The main function for running the game.
   *
   * @param args inputs to the main function.
   */
  public static void main(String[] args) {
    PyramidSolitaireModel model;
    PyramidSolitaireTextualController controller;
    PyramidSolitaireCreator creator = new PyramidSolitaireCreator();
    int c = 0;
    int r = 0;
    try {
      if (1 == args.length) {
        c = 3;
        r = 7;
      } else if (3 == args.length) {
        c = Integer.parseInt(args[2]);
        r = Integer.parseInt(args[1]);
      }
      if (0 > c || 1 > r) {
        throw new IllegalArgumentException("wrong input");
      }
      switch (args[0]) {
        case "basic":
          model = PyramidSolitaireCreator.create(GameType.BASIC);
          if (r > 9) {
            throw new IllegalArgumentException("wrong input");
          }
          break;
        case "tripeaks":
          model = PyramidSolitaireCreator.create(GameType.MULTIPYRAMID);
          if (r > 8) {
            throw new IllegalArgumentException("wrong input");
          }
          break;
        case "relaxed":
          model = PyramidSolitaireCreator.create(GameType.RELAXED);
          if (r > 9) {
            throw new IllegalArgumentException("wrong input");
          }
          break;
        default:
          throw new IllegalArgumentException("no such game type");
      }
      controller =
          new PyramidSolitaireTextualController(new InputStreamReader(System.in), System.out);
      controller.playGame(model, model.getDeck(), false, r, c);
    } catch (IllegalArgumentException ignored) {
    }
  }
}


