package cs3500.pyramidsolitaire.model.hw04;

import cs3500.pyramidsolitaire.model.hw02.Card;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * A basic model for playing a game of pyramid solitaire that maintains the state and enforces the
 * rules of gameplay. Uses the Card class to represent cards. Another variant of the game is called
 * Multi-pyramid. It uses the same rules as the original game, but uses a larger board and a larger
 * deck of cards.
 */
public class MultiPyramidSolitaire extends AbstractPyramidSolitaire {
  /**
   * Return a valid and complete deck of cards for a game of Pyramid Solitaire. There is no
   * restriction imposed on the ordering of these cards in the deck. The validity of the deck is
   * determined by the rules of the specific game in the classes implementing this interface.
   *
   * @return the deck of cards as a list
   */
  public List<Card> getDeck() {
    ArrayList<String> suites = new ArrayList<String>(Arrays.asList("♣", "♥", "♠", "♦"));
    List<Card> deck = new ArrayList<Card>();
    for (String suite : suites) {
      for (int j = 1; j < 14; j++) {
        deck.add(new Card(j, suite));
        deck.add(new Card(j, suite));
      }
    }
    return deck;
  }

  /**
   * change a given deck so that it satisfies the Multi-Pyramid Solitaire structure.
   *
   * @param deck a given deck.
   * @return a changed deck.
   */
  protected List<Card> changePyramid(List<Card> deck) {
    int breaks = changeNum((int) (super.numRows * 1.0 / 2));
    int breaksNum = super.numRows;
    List<Card> baseDeck = new ArrayList<>(deck);
    if (1 == super.numRows) {
      breaksNum = 3;
    }
    if (0 == breaksNum % 2) {
      breaksNum = super.numRows + 1;
    }
    for (int i = 0; i < super.numRows; i++) {
      ArrayList<Card> tempRow = new ArrayList<Card>();
      for (int j = 0; j < i + breaksNum; j++) {
        if (i + 1 > j % (breaks + i)) {
          baseDeck.remove(0);
          tempRow.add(baseDeck.get(0));
        } else {
          tempRow.add(Card.EMPTY_CARD);
        }
      }
      breaks = changeNum(-1 + breaks);
      this.pyramid.add(tempRow);
    }
    System.out.println(this.pyramid);
    return baseDeck;
  }

  /**
   * check if the given row is the max row.
   *
   * @return true if it is the max row.
   */
  protected boolean checkMaxRow(int row) {
    return row > 8;
  }

  /**
   * change the given integer to 1 when it is less than 2.
   *
   * @param n integer.
   * @return given integer.
   */
  static int changeNum(int n) {
    if (2 > n) {
      return 1;
    } else {
      return n;
    }
  }
}