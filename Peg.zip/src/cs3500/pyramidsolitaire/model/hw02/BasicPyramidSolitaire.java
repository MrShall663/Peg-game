package cs3500.pyramidsolitaire.model.hw02;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/**
 * A basic model for playing a game of pyramid solitaire that maintains the state and enforces the
 * rules of gameplay. Uses the Card class to represent cards.
 */
public class BasicPyramidSolitaire implements PyramidSolitaireModel<Card> {

  private List<ArrayList<Card>> pyramid;
  private List<Card> draw;
  private List<Card> stock;
  private int numRows;
  private int numDraw;
  private boolean gameStarted;

  /**
   * constructor for a pyramid solitaire.
   */
  public BasicPyramidSolitaire() {
    this.pyramid = new ArrayList<ArrayList<Card>>();
    this.draw = new ArrayList<Card>();
    this.numRows = -1;
    this.numDraw = -1;
    this.gameStarted = false;
  }

  /**
   * Return a valid and complete deck of cards for a game of Pyramid Solitaire. There is no
   * restriction imposed on the ordering of these cards in the deck. The validity of the deck is
   * determined by the rules of the specific game in the classes implementing this interface.
   *
   * @return the deck of cards as a list
   */
  public List<Card> getDeck() {
    ArrayList<String> suites = new ArrayList<String>(Arrays.asList("♣", "♥", "♠", "♦"));
    List<Card> deck = new ArrayList<Card>();
    for (String suite : suites) {
      for (int i = 1; i < 14; i++) {
        deck.add(new Card(i, suite));
      }
    }
    return deck;
  }

  /**
   * <p>Deal a new game of Pyramid Solitaire.
   * The cards to be used and their order are specified by the the given deck, unless the {@code
   * shuffle} parameter indicates the order should be ignored.</p>
   *
   * <p>This method first verifies that the deck is valid. It deals cards in rows
   * (left-to-right, top-to-bottom) into the characteristic pyramid shape with the specified number
   * of rows, followed by the specified number of draw cards. When {@code shuffle} is {@code false},
   * the 0th card in {@code deck} is used as the first card dealt.</p>
   *
   * <p>This method should have no other side effects, and should work for any valid arguments.</p>
   *
   * @param deck    the deck to be dealt
   * @param shuffle if {@code false}, use the order as given by {@code deck}, otherwise use a
   *                randomly shuffled order
   * @param numRows number of rows in the pyramid
   * @param numDraw number of draw cards available at a time
   * @throws IllegalArgumentException if the deck is null or invalid, the number of pyramid rows is
   *                                  non-positive, the number of draw cards available at a time is
   *                                  negative, or a full pyramid and draw pile cannot be dealt with
   *                                  the number of given cards in deck
   */
  public void startGame(List<Card> deck, boolean shuffle, int numRows, int numDraw) {
    if (deck == null || numRows < 1 || numDraw < 0 || numRows > 9) {
      throw new IllegalArgumentException("null deck or invalid numbers of rows and draws");
    }
    HashSet<Card> cards = new HashSet<>(deck);
    if (!(cards.size() == 52 && deck.size() == cards.size())) {
      throw new IllegalArgumentException("invalid deck");
    }
    this.draw = new ArrayList<Card>();
    this.pyramid = new ArrayList<ArrayList<Card>>();
    List<Card> base = new ArrayList<>(deck);
    if (shuffle) {
      Collections.shuffle(base);
    }
    for (int row = 0; row < numRows; row++) {
      List<Card> tempRow = new ArrayList<Card>();
      for (int i = 0; i < row + 1; i++) {
        tempRow.add(base.get(0));
        base.remove(0);
      }
      this.pyramid.add((ArrayList<Card>) tempRow);
    }
    for (int i = 0; i < numDraw; i++) {
      if (base.size() == 0) {
        break;
      }
      this.draw.add(base.get(0));
      base.remove(0);
    }
    this.stock = base;
    this.numRows = numRows;
    this.numDraw = numDraw;
    this.gameStarted = true;
  }

  /**
   * check whether the game starts or not.
   *
   * @throws IllegalStateException if game did not start
   */
  private void gameStateException() {
    if (!this.gameStarted) {
      throw new IllegalStateException("game not start");
    }
  }

  /**
   * check if the given card is exposed.
   *
   * @param row  row of the given card
   * @param card column of the given card
   * @throws IllegalArgumentException if invalid position given
   */
  private boolean isExposed(int row, int card) {
    if (this.getCardAtReference(row, card) == null) {
      return false;
    }
    if (this.checkRowCard(row, card)) {
      throw new IllegalArgumentException("invalid given row or card");
    }
    if (row == this.pyramid.size() - 1) {
      return true;
    } else {
      return this.getCardAtReference(row + 1, card) == null
          && this.getCardAtReference(row + 1, card + 1) == null;
    }
  }

  /**
   * check if the given position is valid.
   *
   * @param row  row of the card
   * @param card column of the card
   * @return true if the given position is empty or invalid, false otherwise
   */
  private boolean checkRowCard(int row, int card) {
    return row < 0 || row > this.pyramid.size() - 1 || card < 0 || card > this.getRowWidth(row) - 1
        || this.getCardAtReference(row, card) == null;
  }

  /**
   * Remove two exposed cards on the pyramid, using the two specified card positions.
   *
   * @param row1  row of first card position, numbered from 0 from the top of the pyramid
   * @param card1 card of first card position, numbered from 0 from left
   * @param row2  row of second card position
   * @param card2 card of second card position
   * @throws IllegalArgumentException if the attempted remove is invalid
   * @throws IllegalStateException    if the game has not yet been started
   */
  public void remove(int row1, int card1, int row2, int card2) throws IllegalStateException {
    this.gameStateException();
    if (this.checkRowCard(row1, card1) || this.checkRowCard(row2, card2)) {
      throw new IllegalArgumentException("invalid row or card");
    }
    if (row1 == row2 && card1 == card2) {
      throw new IllegalArgumentException("given the same card");
    }
    if (!(this.isExposed(row1, card1) && this.isExposed(row2, card2))) {
      throw new IllegalArgumentException("given cards are not exposed");
    }
    Card c1 = this.getCardAtReference(row1, card1);
    Card c2 = this.getCardAtReference(row2, card2);
    if (c1.getValue() + c2.getValue() != 13) {
      throw new IllegalArgumentException("sum of two cards is not 13" + "card1= "
          + c1.getValue() + " card2= " + c2.getValue());
    }
    this.removeCardHelper(row1, card1);
    this.removeCardHelper(row2, card2);
  }

  /**
   * Remove a single card on the pyramid, using the specified card position.
   *
   * @param row  row of the desired card position, numbered from 0 from the top of the pyramid
   * @param card card of the desired card position, numbered from 0 from left
   * @throws IllegalArgumentException if the attempted remove is invalid
   * @throws IllegalStateException    if the game has not yet been started
   */
  public void remove(int row, int card) throws IllegalStateException {
    this.gameStateException();
    if (this.getCardAtReference(row, card).getValue() == 13) {
      this.removeCardHelper(row, card);
    } else {
      throw new IllegalArgumentException("given card is not king");
    }
  }

  /**
   * Helper for method removeCard.
   *
   * @param row  the given row
   * @param card the given column
   */
  private void removeCardHelper(int row, int card) {
    this.gameStateException();
    if (this.checkRowCard(row, card)) {
      throw new IllegalArgumentException(
          "invalid row or card or do not exist");
    }
    if (!this.isExposed(row, card)) {
      throw new IllegalArgumentException("given card is not exposed");
    }
    this.pyramid.get(row).set(card, Card.EMPTY_CARD);
  }

  /**
   * Remove two cards, one from the draw pile and one from the pyramid.
   *
   * @param drawIndex the card from the draw pile, numbered from 0 from left
   * @param row       row of the desired card position, numbered from 0 from the top of the pyramid
   * @param card      card of the desired card position, numbered from 0 from left
   * @throws IllegalArgumentException if the attempted remove is invalid
   * @throws IllegalStateException    if the game has not yet been started
   */
  public void removeUsingDraw(int drawIndex, int row, int card) throws IllegalStateException {
    this.gameStateException();
    if (drawIndex > this.draw.size() - 1 || drawIndex < 0 || this.checkRowCard(row, card)) {
      throw new IllegalArgumentException(
          "row/card value invalid or drawIndex invalid" + "row: " + row + "card: " + card
              + "index: " + drawIndex + "drawsize: " + this.getDrawCards().size());
    }
    if (!this.isExposed(row, card)) {
      throw new IllegalArgumentException("given card is not exposed");
    }
    Card c1 = this.draw.get(drawIndex);
    Card c2 = this.getCardAtReference(row, card);
    if (c1.getValue() + c2.getValue() != 13) {
      throw new IllegalArgumentException(
          "sum of two cards is not 13" + "card1= " + c1 + " card2= " + c2);
    }
    this.removeCardHelper(row, card);
    this.discardDraw(drawIndex);
  }

  /**
   * Discards an individual card from the draw pile.
   *
   * @param drawIndex the card from the draw pile to be discarded
   * @throws IllegalArgumentException if the index is invalid or no card is present there.
   * @throws IllegalStateException    if the game has not yet been started
   */
  public void discardDraw(int drawIndex) throws IllegalStateException {
    this.gameStateException();
    if (drawIndex > this.draw.size() - 1 || drawIndex < 0) {
      throw new IllegalArgumentException("invalid drawindex");
    }
    if (this.stock.size() != 0) {
      this.draw.set(drawIndex, this.stock.get(0));
      this.stock.remove(0);
    } else {
      this.draw.remove(drawIndex);
    }
  }

  /**
   * Returns the number of rows originally in the pyramid, or -1 if the game hasn't been started.
   *
   * @return the height of the pyramid, or -1
   */
  public int getNumRows() {
    return this.numRows;
  }

  /**
   * Returns the maximum number of visible cards in the draw pile, or -1 if the game hasn't been
   * started.
   *
   * @return the number of visible cards in the draw pile, or -1
   */
  public int getNumDraw() {
    return this.numDraw;
  }

  /**
   * Returns the width of the requested row, measured from the leftmost card to the rightmost card
   * (inclusive) as the game is initially dealt.
   *
   * @param row the desired row (0-indexed)
   * @return the number of spaces needed to deal out that row
   * @throws IllegalArgumentException if the row is invalid
   * @throws IllegalStateException    if the game has not yet been started
   */
  public int getRowWidth(int row) {
    this.gameStateException();
    if (row < 0 || row > this.pyramid.size() - 1) {
      throw new IllegalArgumentException("invalid row");
    }
    return row + 1;
  }

  /**
   * Signal if the game is over or not. A game is said to be over if there are no possible removes
   * or discards.
   *
   * @return true if game is over, false otherwise
   * @throws IllegalStateException if the game hasn't been started yet
   */
  public boolean isGameOver() throws IllegalStateException {
    this.gameStateException();
    if (this.getScore() == 0) {
      return true;
    }
    if ((this.stock.size() + this.draw.size()) != 0) {
      return false;
    } else {
      ArrayList<Card> base = new ArrayList<Card>();
      for (int i = 0; i < this.pyramid.size(); i++) {
        for (int j = 0; j < this.pyramid.get(i).size(); j++) {
          try {
            if (this.isExposed(i, j)) {
              base.add(this.getCardAtReference(i, j));
            }
          } catch (IllegalArgumentException e) {
            throw new IllegalStateException("");
          }
        }
      }
      for (Card c1 : base) {
        if (c1.getValue() == 13) {
          return false;
        }
        for (Card c2 : base) {
          if (c1.getValue() + c2.getValue() == 13) {
            return false;
          }
        }
      }
      return true;
    }
  }

  /**
   * Return the current score, which is the sum of the values of the cards remaining in the
   * pyramid.
   *
   * @return the score
   * @throws IllegalStateException if the game hasn't been started yet
   */
  public int getScore() throws IllegalStateException {
    this.gameStateException();
    int total = 0;
    for (ArrayList<Card> alc : this.pyramid) {
      for (Card c : alc) {
        total = total + c.getValue();
      }
    }
    return total;
  }

  /**
   * Returns the card at the specified coordinates.
   *
   * @param row  row of the desired card (0-indexed from the top)
   * @param card column of the desired card (0-indexed from the left)
   * @return the card at the given position, or <code>null</code> if no card is there
   * @throws IllegalArgumentException if the coordinates are invalid
   * @throws IllegalStateException    if the game hasn't been started yet
   */
  public Card getCardAt(int row, int card) throws IllegalStateException {
    Card base = this.getCardAtReference(row, card);
    if (base == null) {
      return null;
    }
    base = new Card(base.getValue(), base.getSuite());
    return base;
  }

  /**
   * Returns the currently available draw cards. There should be at most {@link
   * PyramidSolitaireModel#getNumDraw} cards (the number specified when the game started) -- there
   * may be fewer, if cards have been removed.
   *
   * @return the ordered list of available draw cards
   * @throws IllegalStateException if the game hasn't been started yet
   */
  public List<Card> getDrawCards() throws IllegalStateException {
    this.gameStateException();
    List<Card> base = new ArrayList<Card>(this.draw);
    return base;
  }

  /**
   * get the card being removed.
   *
   * @param row  the given row of the card
   * @param card the given column of the card
   * @return a card being removed
   * @throws IllegalStateException if invalid position is given
   */
  private Card getCardAtReference(int row, int card) throws IllegalStateException {
    this.gameStateException();
    if (row < 0 || row > this.numRows - 1 || card < 0 || card > this.getRowWidth(row) - 1) {
      throw new IllegalArgumentException("invalid row or card");
    }
    Card c = this.pyramid.get(row).get(card);
    if (c.getValue() == 0) {
      return null;
    }
    else {
      return c;
    }
  }
}