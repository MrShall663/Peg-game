package cs3500.pyramidsolitaire.model.hw02;

/**
 * represent a card with value and suit there is also a empty card.
 */
public class Card {

  private final int value;
  private final String suit;
  public static final Card EMPTY_CARD = new Card(0, "♣");

  /**
   * constructor for a card.
   *
   * @param v the value of the card.
   * @param s the suite of the card, have four suits
   * @throws IllegalArgumentException if invalid suit or value given.
   */
  public Card(int v, String s) {
    if (v < 0 || v > 13 || !(s.equals("♣") || s.equals("♥") || s.equals("♠") || s.equals("♦"))) {
      throw new IllegalArgumentException("invalid value or suit");
    }
    this.value = v;
    this.suit = s;
  }

  @Override
  public String toString() {
    String base = "";
    if (value == 0) {
      base = "  ";
    } else if (value == 1) {
      base = "A" + suit;
    } else if (value <= 10) {
      base = value + suit;
    } else if (value == 11) {
      base = "J" + suit;
    } else if (value == 12) {
      base = "Q" + suit;
    } else if (value == 13) {
      base = "K" + suit;
    }
    return base;
  }

  @Override
  public boolean equals(Object o) {
    if (!(o instanceof Card)) {
      return false;
    }
    return (((Card) o).value == this.value && ((Card) o).suit.equals(this.suit))
        || (((Card) o).value == 0 && this.value == 0);
  }

  @Override
  public int hashCode() {
    if (value == 0) {
      return 0;
    }
    switch (suit) {
      case "♣":
        return value;
      case "♥":
        return value + 13;
      case "♠":
        return value + 26;
      default:
        return value + 39;
    }
  }

  /**
   * gets the value.
   *
   * @return this value
   */
  public int getValue() {
    return this.value;
  }

  /**
   * gets the suite.
   *
   * @return this suite
   */
  public String getSuite() {
    return this.suit;
  }
}

