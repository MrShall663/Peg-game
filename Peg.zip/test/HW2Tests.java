import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;

import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw02.Card;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;
import cs3500.pyramidsolitaire.view.PyramidSolitaireTextualView;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;

/**
 * Tests for pyramid solitaire.
 */
public class HW2Tests {

  /**
   * Testing models.
   */
  public static class Hw02Tests {

    PyramidSolitaireModel<Card> model = new BasicPyramidSolitaire();
    PyramidSolitaireTextualView view = new PyramidSolitaireTextualView(model);
    PyramidSolitaireModel<Card> winModel = new BasicPyramidSolitaire();
    PyramidSolitaireTextualView winScene = new PyramidSolitaireTextualView(winModel);
    PyramidSolitaireModel<Card> lossModel = new BasicPyramidSolitaire();
    PyramidSolitaireTextualView lossView = new PyramidSolitaireTextualView(lossModel);
    List<Card> bigDeck = model.getDeck();
    List<Card> smallDeck = model.getDeck();
    List<Card> dupeDeck = model.getDeck();
    List<Card> shiftedDeck = model.getDeck();
    List<Card> validDraw = new ArrayList<Card>();
    Card aceSpade = new Card(2, "♠");
    Card aceSpade2 = new Card(2, "♠");
    Card sevenClover = new Card(6, "♣");
    Card eightClover = new Card(9, "♣");

    private void initData() {
      bigDeck.add(aceSpade);
      smallDeck.remove(0);
      dupeDeck.remove(4);
      dupeDeck.add(aceSpade);
      validDraw.add(sevenClover);
      validDraw.add(eightClover);
      Card temp = shiftedDeck.get(0);
      shiftedDeck.set(0, shiftedDeck.get(51));
      shiftedDeck.set(51, temp);
      System.out.println(shiftedDeck);
      winModel.startGame(shiftedDeck, false, 1, 51);
      winModel.remove(0, 0);
      lossModel.startGame(lossModel.getDeck(), false, 1, 51);
    }


    @Test(expected = IllegalStateException.class)
    public void test1() {
      model.remove(0, 0, 1, 1);
    }

    @Test(expected = IllegalStateException.class)
    public void test2() {
      model.getCardAt(0, 0);
    }


    @Test(expected = IllegalStateException.class)
    public void test3() {
      model.getDrawCards();
    }

    @Test(expected = IllegalStateException.class)
    public void test4() {
      model.removeUsingDraw(0, 0, 0);
    }

    @Test(expected = IllegalStateException.class)
    public void test5() {
      model.discardDraw(0);
    }

    @Test(expected = IllegalStateException.class)
    public void test6() {
      model.getRowWidth(0);
    }

    @Test(expected = IllegalStateException.class)
    public void test7() {
      model.isGameOver();
    }

    @Test(expected = IllegalStateException.class)
    public void test8() {
      model.remove(0, 0);
    }


    @Test(expected = IllegalStateException.class)
    public void test9() {
      model.getScore();
    }

    @Test(expected = IllegalStateException.class)
    public void test10() {
      model.getCardAt(0, 0);
    }


    @Test(expected = IllegalArgumentException.class)
    public void testStartGameFunction1() {
      model.startGame(model.getDeck(), true, -1, 1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testStartGameFunction2() {
      model.startGame(model.getDeck(), true, 3, -1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testStartGameFunction3() {
      List<Card> testdeck = model.getDeck();
      testdeck.remove(0);
      model.startGame(testdeck, true, 3, 1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testStartGameFunction4() {
      List<Card> testdeck = model.getDeck();
      testdeck.remove(0);
      testdeck.add(testdeck.get(0));
      model.startGame(testdeck, true, 3, 1);
    }

    @Test
    public void testStartGameFunction5() {
      this.initData();
      model.startGame(model.getDeck(), false, 3, 2);
      model.startGame(model.getDeck(), false, 3, 2);
      assertEquals(2, model.getNumDraw());
      assertEquals(3, model.getNumRows());
      assertEquals(this.validDraw, model.getDrawCards());
    }

    @Test
    public void testRemoveTwo1() {
      this.initData();
      model.startGame(model.getDeck(), false, 5, 2);
      model.remove(4, 0, 4, 4);
      assertNull(model.getCardAt(4, 0));
      assertNull(model.getCardAt(4, 4));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveTwo2() {
      this.initData();
      model.startGame(model.getDeck(), false, 5, 2);
      model.remove(4, 0, 4, 1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveTwo3() {
      this.initData();
      model.startGame(model.getDeck(), false, 5, 2);
      model.remove(-4, 0, 4, -1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveTwo4() {
      this.initData();
      model.startGame(model.getDeck(), false, 5, 2);
      model.remove(20, 0, 4, 20);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveTwo5() {
      this.initData();
      model.startGame(model.getDeck(), false, 5, 2);
      model.remove(0, 0, 4, 1);
    }


    @Test(expected = IllegalArgumentException.class)
    public void testRemove1() {
      this.initData();
      model.startGame(model.getDeck(), false, 5, 2);
      model.remove(-4, -3);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemove2() {
      this.initData();
      model.startGame(model.getDeck(), false, 5, 2);
      model.remove(15, 15);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemove3() {
      this.initData();
      model.startGame(model.getDeck(), false, 5, 2);
      model.remove(4, 1);
    }

    @Test
    public void testRemove4() {
      this.initData();
      model.startGame(model.getDeck(), false, 5, 2);
      model.remove(4, 2);
      assertNull(model.getCardAt(4, 2));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemove5() {
      this.initData();
      model.startGame(model.getDeck(), false, 6, 13);
      model.remove(4, 2);
    }

    @Test
    public void testRemoveDraw1() {
      this.initData();
      model.startGame(model.getDeck(), false, 5, 13);
      model.removeUsingDraw(12, 4, 0);
      assertNull(model.getCardAt(4, 0));
      assertEquals(3, model.getDrawCards().get(12).getValue());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveDraw2() {
      this.initData();
      model.startGame(model.getDeck(), false, 5, 13);
      model.removeUsingDraw(12, 4, 1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveDraw3() {
      this.initData();
      model.startGame(model.getDeck(), false, 5, 13);
      model.removeUsingDraw(-12, 4, 0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveDraw4() {
      this.initData();
      model.startGame(model.getDeck(), false, 5, 13);
      model.removeUsingDraw(12, -4, -3);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveDraw5() {
      this.initData();
      model.startGame(model.getDeck(), false, 5, 13);
      model.removeUsingDraw(20, 4, 0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveDraw6() {
      this.initData();
      model.startGame(model.getDeck(), false, 5, 13);
      model.removeUsingDraw(9, 0, 0);
    }

    @Test
    public void testDiscard1() {
      this.initData();
      model.startGame(model.getDeck(), false, 5, 3);
      model.discardDraw(0);
      assertEquals(6, model.getDrawCards().get(0).getValue());
    }

    @Test
    public void testDiscard2() {
      this.initData();
      model.startGame(model.getDeck(), false, 1, 51);
      model.discardDraw(0);
      assertEquals(50, model.getDrawCards().size());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDiscard3() {
      this.initData();
      model.startGame(model.getDeck(), false, 1, 51);
      model.discardDraw(-1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDiscard4() {
      this.initData();
      model.startGame(model.getDeck(), false, 1, 51);
      model.discardDraw(51);
    }

    @Test
    public void testNumDraw1() {
      this.initData();
      model.startGame(model.getDeck(), false, 1, 51);
      assertEquals(model.getNumDraw(), 51);
    }

    @Test
    public void testNumDraw2() {
      this.initData();
      assertEquals(model.getNumDraw(), -1);
    }

    @Test
    public void testNumRows1() {
      this.initData();
      model.startGame(model.getDeck(), false, 1, 51);
      assertEquals(model.getNumRows(), 1);
    }

    @Test
    public void testNumRows2() {
      this.initData();
      assertEquals(model.getNumRows(), -1);
    }

    @Test
    public void testGetRowWidth1() {
      this.initData();
      model.startGame(model.getDeck(), false, 5, 3);
      assertEquals(model.getRowWidth(2), 3);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetRowWidth2() {
      this.initData();
      model.startGame(model.getDeck(), false, 5, 3);
      model.getRowWidth(-1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetRowWidth3() {
      this.initData();
      model.startGame(model.getDeck(), false, 5, 3);
      model.getRowWidth(5);
    }

    @Test
    public void testGetScore1() {
      this.initData();
      model.startGame(model.getDeck(), false, 2, 3);
      assertEquals(model.getScore(), 6);
    }

    @Test
    public void testGetCardAt1() {
      this.initData();
      model.startGame(model.getDeck(), false, 2, 3);
      assertEquals(new Card(1, "♣"), model.getCardAt(0, 0));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetCardAt2() {
      this.initData();
      model.startGame(model.getDeck(), false, 2, 3);
      model.getCardAt(-1, -1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetCardAt3() {
      this.initData();
      model.startGame(model.getDeck(), false, 2, 3);
      model.getCardAt(4, 4);
    }

    @Test
    public void testGetDrawCards() {
      this.initData();
      model.startGame(model.getDeck(), false, 3, 2);
      assertEquals(this.validDraw, model.getDrawCards());
    }

    @Test
    public void testCardEquals1() {
      this.initData();
      assertEquals(this.aceSpade, this.aceSpade2);
    }

    @Test
    public void testCardEquals2() {
      this.initData();
      assertNotEquals(this.aceSpade, this.eightClover);
    }

    @Test
    public void testCardToString() {
      this.initData();
      assertEquals("A♠", this.aceSpade.toString());
      assertEquals("  ", Card.EMPTY_CARD.toString());
    }

    @Test
    public void testCardGetSuite() {
      this.initData();
      assertEquals("♠", this.aceSpade.getSuite());
    }

    @Test
    public void testCardGetValue() {
      this.initData();
      assertEquals(1, this.aceSpade.getValue());
    }

    @Test
    public void testHashCode() {
      this.initData();
      assertEquals(27, this.aceSpade.hashCode());
      assertEquals(0, Card.EMPTY_CARD.hashCode());
    }

    @Test
    public void testView1() {
      this.initData();
      assertEquals("", this.view.toString());
    }

    @Test
    public void testView2() {
      this.initData();
      assertEquals("You win!", this.winScene.toString());
    }

    @Test
    public void testView3() {
      this.initData();
      model.startGame(model.getDeck(), false, 5, 3);
      assertEquals("        A♣\n" + "      2♣  3♣\n" + "    4♣  5♣  6♣\n" + "  7♣  8♣  9♣  10♣\n"
          + "J♣  Q♣  K♣  A♥  2♥\n" + "Draw: 3♥, 4♥, 5♥", this.view.toString());
    }

    @Test
    public void testView4() {
      this.initData();
      assertEquals("Game over. Score: 1", lossView.toString());
    }

    @Test
    public void testGameOver1() {
      this.initData();
      model.startGame(model.getDeck(), false, 5, 3);
      assertEquals(false, model.isGameOver());
    }

    @Test
    public void testGameOver2() {
      this.initData();
      assertEquals(true, winModel.isGameOver());
    }

    @Test
    public void testGameOver3() {
      this.initData();
      assertEquals(true, lossModel.isGameOver());
    }
  }
}