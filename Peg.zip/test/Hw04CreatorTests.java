import static org.junit.Assert.assertEquals;

import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw04.MultiPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw04.PyramidSolitaireCreator;
import cs3500.pyramidsolitaire.model.hw04.PyramidSolitaireCreator.GameType;
import cs3500.pyramidsolitaire.model.hw04.RelaxedPyramidSolitaire;
import org.junit.Test;

/**
 * tests for the creator of the pyramid solitaire.
 */
public class Hw04CreatorTests {

  @Test
  public void testBasic() {
    assertEquals(new BasicPyramidSolitaire(), PyramidSolitaireCreator.create(GameType.BASIC));
  }

  @Test
  public void testMultiPyramid() {
    assertEquals(new MultiPyramidSolitaire(),
        PyramidSolitaireCreator.create(GameType.MULTIPYRAMID));
  }

  @Test
  public void testRelaxed() {
    assertEquals(new RelaxedPyramidSolitaire(), PyramidSolitaireCreator.create(GameType.RELAXED));
  }
}
