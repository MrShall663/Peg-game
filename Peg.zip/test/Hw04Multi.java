import static org.junit.Assert.assertEquals;

import cs3500.pyramidsolitaire.model.hw02.Card;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;
import cs3500.pyramidsolitaire.model.hw04.MultiPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw04.RelaxedPyramidSolitaire;
import cs3500.pyramidsolitaire.view.PyramidSolitaireTextualView;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;

/**
 * tests for multi-pyramid solitaire.
 */
public class Hw04Multi {

  Card card1 = new Card(3, "♦");
  Card card2 = new Card(2, "♠");
  Card card3 = new Card(9, "♣");
  Card card4 = new Card(6, "♥");
  Card card5 = new Card(1, "♦");
  Card card6 = new Card(4, "♠");
  Card card7 = new Card(5, "♣");
  Card card8 = new Card(8, "♥");
  PyramidSolitaireModel<Card> model = new RelaxedPyramidSolitaire();
  PyramidSolitaireModel<Card> winModel = new RelaxedPyramidSolitaire();
  PyramidSolitaireModel<Card> lossModel = new RelaxedPyramidSolitaire();
  PyramidSolitaireTextualView view = new PyramidSolitaireTextualView(model);
  PyramidSolitaireTextualView winView = new PyramidSolitaireTextualView(winModel);
  PyramidSolitaireTextualView lossView = new PyramidSolitaireTextualView(lossModel);
  PyramidSolitaireModel<Card> model1 = new MultiPyramidSolitaire();
  List<Card> badDeck = model.getDeck();
  List<Card> draw = new ArrayList<Card>();
  List<Card> smallDeck = model.getDeck();
  List<Card> bigDeck = model.getDeck();
  List<Card> shiftedDeck = model.getDeck();
  List<Card> goodDeck = model.getDeck();
  List<Card> meanDeck = model.getDeck();

  /**
   * initial data.
   */
  private void initialData() {
    System.out.println(shiftedDeck);
    winModel.startGame(shiftedDeck, false, 1, 51);
    winModel.remove(0, 0);
    shiftedDeck.set(0, shiftedDeck.get(51));
    bigDeck.add(card1);
    draw.add(card3);
    draw.add(card4);
    badDeck.add(card1);
    goodDeck.add(card1);
    goodDeck.add(card1);
    goodDeck.add(card1);
    meanDeck.add(card3);
    smallDeck.remove(0);
    badDeck.remove(4);
    meanDeck.remove(0);
    meanDeck.remove(2);
    meanDeck.remove(3);
    meanDeck.remove(5);
    Card temp = shiftedDeck.get(0);
    shiftedDeck.set(51, temp);
    lossModel.startGame(lossModel.getDeck(), false, 1, 51);
    while (lossModel.getDrawCards().size() != 0) {
      lossModel.discardDraw(0);
    }
    System.out.println(lossModel.getScore());
    System.out.println(lossView.toString());
    System.out.println(lossModel.getDrawCards());
  }

  @Test(expected = IllegalStateException.class)
  public void testGameStart1() {
    model.getCardAt(1, 1);
  }

  @Test(expected = IllegalStateException.class)
  public void testGameStart2() {
    model.getCardAt(0, 0);
  }

  @Test(expected = IllegalStateException.class)
  public void testGameStart3() {
    model.remove(1, 3, 0, 0);
  }

  @Test(expected = IllegalStateException.class)
  public void testGameStart4() {
    model.remove(0, 0, 0, 0);
  }

  @Test(expected = IllegalStateException.class)
  public void testGameStart5() {
    model.remove(0, 0);
  }

  @Test(expected = IllegalStateException.class)
  public void testGameStart6() {
    model.remove(2, 2);
  }

  @Test(expected = IllegalStateException.class)
  public void testGameStart7() {
    model.removeUsingDraw(0, 0, 0);
  }

  @Test(expected = IllegalStateException.class)
  public void testGameStart8() {
    model.removeUsingDraw(1, 2, 3);
  }

  @Test(expected = IllegalStateException.class)
  public void testGameStart9() {
    model.discardDraw(0);
  }

  @Test(expected = IllegalStateException.class)
  public void testGameStart10() {
    model.isGameOver();
  }

  @Test(expected = IllegalStateException.class)
  public void testGameStart11() {
    model.getDrawCards();
  }

  @Test(expected = IllegalStateException.class)
  public void testGameStart12() {
    model.getScore();
  }

  @Test(expected = IllegalStateException.class)
  public void testGameStart13() {
    model.getCardAt(0, 0);
  }

  @Test(expected = IllegalStateException.class)
  public void testGameStart14() {
    model.getRowWidth(0);
  }

  @Test(expected = IllegalStateException.class)
  public void testGameStart15() {
    model.getRowWidth(1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testStartGameFunction1() {
    model.startGame(model.getDeck(), true, -10, 8);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testStartGameFunction2() {
    model.startGame(model.getDeck(), true, 4, -18);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testStartGameFunction3() {
    model.startGame(model.getDeck(), true, -4, -18);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testStartGameFunction4() {
    List<Card> testDeck = model.getDeck();
    testDeck.remove(0);
    testDeck.add(testDeck.get(0));
    model.startGame(testDeck, true, 2, 3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testStartGameFunction5() {
    List<Card> testDeck = model.getDeck();
    testDeck.remove(0);
    model.startGame(testDeck, true, 5, 8);
  }

  @Test
  public void testStartGameFunction6() {
    this.initialData();
    model.startGame(model.getDeck(), false, 1, 4);
    model.startGame(model.getDeck(), false, 1, 4);
    assertEquals(1, model.getNumDraw());
    assertEquals(4, model.getNumRows());
    assertEquals(this.draw, model.getDrawCards());
  }

  @Test
  public void testStartGameFunction7() {
    this.initialData();
    model.startGame(model.getDeck(), false, 2, 3);
    model.startGame(model.getDeck(), false, 2, 3);
    assertEquals(2, model.getNumDraw());
    assertEquals(3, model.getNumRows());
    assertEquals(this.draw, model.getDrawCards());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRemove0() {
    this.initialData();
    model.startGame(model.getDeck(), false, 2, 3);
    model.remove(-9, -9);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRemove1() {
    this.initialData();
    model.startGame(model.getDeck(), false, 2, 3);
    model.remove(-1, -2);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRemove2() {
    this.initialData();
    model.startGame(model.getDeck(), false, 2, 3);
    model.remove(19, 5);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRemove3() {
    this.initialData();
    model.startGame(model.getDeck(), false, 8, 3);
    model.remove(0, 2);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRemove4() {
    this.initialData();
    model.startGame(model.getDeck(), false, 1, 4);
    model.remove(3, 2);
  }

  @Test
  public void testRemove5() {
    this.initialData();
    model.startGame(model.getDeck(), false, 1, 4);
    model.remove(1, 4);
    assertEquals(null, model.getCardAt(4, 1));
  }


  @Test
  public void testRemoveTwo0() {
    this.initialData();
    model.startGame(model.getDeck(), false, 1, 2);
    model.remove(0, 0, 0, 0);
    assertEquals(null, model.getCardAt(5, 5));
    assertEquals(null, model.getCardAt(2, 4));
  }

  @Test
  public void testRemoveTwo1() {
    this.initialData();
    model.startGame(model.getDeck(), false, 3, 1);
    model.remove(2, 1, 2, 2);
    assertEquals(null, model.getCardAt(3, 1));
    assertEquals(null, model.getCardAt(1, 3));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRemoveTwo2() {
    this.initialData();
    model.startGame(model.getDeck(), false, 2, 5);
    model.remove(2, 2, 1, 1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRemoveTwo3() {
    this.initialData();
    model.startGame(model.getDeck(), false, 2, 1);
    model.remove(-10, 0, -4, 9);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRemoveTwo4() {
    this.initialData();
    model.startGame(model.getDeck(), false, 8, 4);
    model.remove(900, 200, 4, 100);
  }

  @Test
  public void testRemoveTwo5() {
    this.initialData();
    model.startGame(model.getDeck(), false, 4, 10);
    System.out.println("Test remove 2 ");
    model.removeUsingDraw(6, 3, 2);
    model.remove(3, 1, 2, 1);
    assertEquals(null, model.getCardAt(3, 1));
    assertEquals(null, model.getCardAt(2, 1));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRemoveTwo6() {
    this.initialData();
    model.startGame(model.getDeck(), false, 2, 3);
    model.remove(2, 3, 2, 3);
  }

  @Test
  public void testRemoveDraw0() {
    this.initialData();
    model.startGame(model.getDeck(), false, 12, 3);
    model.removeUsingDraw(1, 7, 4);
    assertEquals(model.getCardAt(1, 3), null);
    assertEquals(2, model.getDrawCards().get(1).getValue());
  }

  @Test
  public void testRemoveDraw1() {
    this.initialData();
    model.startGame(model.getDeck(), false, 13, 3);
    model.removeUsingDraw(8, 7, 4);
    assertEquals(model.getCardAt(2, 3), null);
    assertEquals(2, model.getDrawCards().get(4).getValue());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRemoveDraw2() {
    this.initialData();
    model.startGame(model.getDeck(), false, 13, 5);
    model.removeUsingDraw(4, 12, 5);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRemoveDraw3() {
    this.initialData();
    model.startGame(model.getDeck(), false, 13, 4);
    model.removeUsingDraw(-55, 2, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRemoveDraw4() {
    this.initialData();
    model.startGame(model.getDeck(), false, 13, 4);
    model.removeUsingDraw(9, -2, -8);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRemoveDraw5() {
    this.initialData();
    model.startGame(model.getDeck(), false, 20, 13);
    model.removeUsingDraw(2, 4, 8);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRemoveDraw6() {
    this.initialData();
    model.startGame(model.getDeck(), false, 20, 3);
    model.removeUsingDraw(2, 7, 2);
  }


  @Test
  public void testNumDraw1() {
    this.initialData();
    model.startGame(model.getDeck(), false, 2, 51);
    assertEquals(model.getNumDraw(), 51);
  }

  @Test
  public void testNumDraw2() {
    this.initialData();
    assertEquals(model.getNumDraw(), -12);
  }

  @Test
  public void testNumRows1() {
    this.initialData();
    model.startGame(model.getDeck(), false, 2, 51);
    assertEquals(model.getNumRows(), 10);
  }

  @Test
  public void testNumRows2() {
    this.initialData();
    assertEquals(model.getNumRows(), -12);
  }

  @Test
  public void testDiscard1() {
    this.initialData();
    model.startGame(model.getDeck(), false, 5, 3);
    model.discardDraw(0);
    assertEquals(6, model.getDrawCards().get(0).getValue());
  }

  @Test
  public void testDiscard2() {
    this.initialData();
    model.startGame(model.getDeck(), false, 1, 51);
    model.discardDraw(0);
    assertEquals(50, model.getDrawCards().size());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testDiscard3() {
    this.initialData();
    model.startGame(model.getDeck(), false, 2, 21);
    model.discardDraw(-8);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testDiscard4() {
    this.initialData();
    model.startGame(model.getDeck(), false, 2, 51);
    model.discardDraw(51);
  }

  @Test
  public void testGetRowWidth1() {
    this.initialData();
    model.startGame(model.getDeck(), false, 2, 7);
    assertEquals(model.getRowWidth(1), 4);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetRowWidth2() {
    this.initialData();
    model.startGame(model.getDeck(), false, 2, 7);
    model.getRowWidth(-1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetRowWidth3() {
    this.initialData();
    model.startGame(model.getDeck(), false, 2, 7);
    model.getRowWidth(1);
  }

  @Test
  public void testGetScore1() {
    this.initialData();
    model.startGame(model.getDeck(), false, 4, 5);
    assertEquals(model.getScore(), 8);
  }

  @Test
  public void testGetScore2() {
    this.initialData();
    model.startGame(model.getDeck(), false, 8, 5);
    assertEquals(model.getScore(), 7);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetCardAt1() {
    this.initialData();
    model.startGame(model.getDeck(), false, 2, 2);
    model.getCardAt(3, 3);
  }

  @Test
  public void testGetCardAt2() {
    this.initialData();
    model.startGame(model.getDeck(), false, 2, 3);
    assertEquals(new Card(2, "♣"), model.getCardAt(0, 0));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetCardAt3() {
    this.initialData();
    model.startGame(model.getDeck(), false, 7, 7);
    model.getCardAt(-2, -2);
  }

  @Test
  public void testGetDrawCards() {
    this.initialData();
    model.startGame(model.getDeck(), false, 8, 8);
    assertEquals(this.draw, model.getDrawCards());
  }

  @Test
  public void testCardEquals1() {
    this.initialData();
    assertEquals(true, this.card2.equals(this.card1));
  }

  @Test
  public void testCardEquals2() {
    this.initialData();
    assertEquals(false, this.card2.equals(this.card5));
  }


  @Test
  public void testCardGetSuite() {
    this.initialData();
    assertEquals("♠", this.card1.getSuite());
  }

  @Test
  public void testCardToString() {
    this.initialData();
    assertEquals("K♣", this.card1.toString());
    assertEquals("  ", Card.EMPTY_CARD.toString());
  }


  @Test
  public void testCardGetValue() {
    this.initialData();
    assertEquals(14, this.card1.getValue());
  }


  @Test
  public void testIsGameOver3() {
    this.initialData();
    assertEquals(true, lossModel.isGameOver());
  }

  @Test
  public void testPyramidView4() {
    this.initialData();
    assertEquals("Game over. Score: 4", lossView.toString());
  }

  @Test
  public void testPyramidView1() {
    this.initialData();
    assertEquals("", this.view.toString());
  }

  @Test
  public void testPyramidView2() {
    this.initialData();
    assertEquals("You win!", this.winView.toString());
  }

  @Test
  public void testPyramidView3() {
    this.initialData();
    model.startGame(model.getDeck(), false, 5, 3);
    assertEquals("        K♠\n" + "      4♥  6♣\n" + "    1♣  2♥  3♣\n" + "  Q♣ K♥  2♥  10♣\n"
        + "2♠  7♠  1♣  4♣  9♥\n" + "Draw: 8♣, 5♣, 7♥", this.view.toString());
  }

  @Test
  public void testIsGameOver1() {
    this.initialData();
    model.startGame(model.getDeck(), false, 5, 3);
    assertEquals(false, model.isGameOver());
  }

  @Test
  public void testIsGameOver2() {
    this.initialData();
    assertEquals(true, winModel.isGameOver());
  }
}
